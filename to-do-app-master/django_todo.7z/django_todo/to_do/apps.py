from django.apps import AppConfig


class ToDoConfig(AppConfig):
    name = 'to_do'
